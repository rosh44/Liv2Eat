import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { DemoFirebasePage } from '../demo-firebase/demo-firebase';
import { FriendsPage } from '../friends/friends';
import { WalletPage } from '../wallet/wallet';

@Component({
  selector: 'page-about',
  templateUrl: 'profile.html'
})
export class ProfilePage {


  constructor(public navCtrl: NavController) {
    
  }

  goDemoPage() {
  this.navCtrl.setRoot(DemoFirebasePage); }
  
  goFriendsPage() {
    this.navCtrl.push(FriendsPage); }
  goWalletPage()
  {
    this.navCtrl.push(WalletPage);
  }
}

