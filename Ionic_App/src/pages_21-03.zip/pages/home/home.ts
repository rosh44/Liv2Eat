import { Component } from '@angular/core';
import { NavController, Menu } from 'ionic-angular';
import {MenuPage} from '../menu/menu';
import { ProfilePage } from '../profile/profile';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {


  constructor(public navCtrl: NavController) {
    
  }

  goMenuPage() {
    this.navCtrl.setRoot(MenuPage); 
  }

    goProfilePage() {
      this.navCtrl.setRoot(ProfilePage);
     }
}
