import { Component } from '@angular/core';

import { ProfilePage } from '../profile/profile';
import { MenuPage } from '../menu/menu';
import { HomePage } from '../home/home';

import { StatusPage } from '../status/status';



@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = HomePage;
  tab2Root = ProfilePage;
  tab3Root = MenuPage;
  tab4Root = StatusPage;
   
  constructor() {



  }
}
