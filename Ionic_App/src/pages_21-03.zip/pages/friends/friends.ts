import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FirebaseProvider } from './../../providers/firebase/firebase';
import {AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database';
import firebase from 'firebase';
/**
 * Generated class for the FriendsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-friends',
  templateUrl: 'friends.html',
})
export class FriendsPage {
  menuCategory: FirebaseListObservable<any[]>;
	menuItems:  FirebaseListObservable<any[]>;
	keys : any[];
	items : any[];
	foodItems:any[]=new Array();
	items1:any[];
	items2: any[]=new Array();
	loadedItems:any[]=new Array();
	searchItems1:any[]=new Array();
	subitems:any[]=new Array();
	subitems1:any[]=new Array();
	ordereditems: any[]=new Array();
	menu:any;
	cost: any[]= new Array();
	dataItems:any[];
	aip:any[]=new Array();
	aip2:any[]=new Array();
	data:FirebaseListObservable<any[]>;
  constructor(public navCtrl: NavController, public navParams: NavParams, public firebaseProvider: FirebaseProvider, public afd: AngularFireDatabase) {
    this.initializeItems();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FriendsPage');
  }

  initializeItems(){
    this.menuItems = this.firebaseProvider.getUserId(); 
    console.log(this.menuItems);
      //try jagged array
      this.firebaseProvider.getUserId().forEach(item=> {
        this.items=Object.keys(item);
        console.log(item[0].$key);
        for(let x in this.items)
      { 	
        console.log(x);
        this.items2.push({ name:item[x].Name, email:item[x].Email,id:item[x].$key});
      }
      console.log(this.items2);
      });
    //this.items2 = this.loadedItems;
    
    console.log("inside initialize");
  
      }
  
      getItems(searchbar) {
    // Reset items back to all of the items
    this.initializeItems();
    
    // set q to the value of the searchbar
    var q = searchbar.srcElement.value;
      // if the value is an empty string don't filter the items
    if (!q) {
      return;
    }
    this.subitems1.length=0;
    for(let x in this.items2){
      this.subitems.length=0;
      this.subitems.push(this.items2[x]);
      console.log(this.subitems);
      for(let y in this.subitems){
      console.log(this.subitems[y]);
      //this.searchItems1 = 
      //console.log(this.items2[x][y]);
       this.items2[x]=this.subitems[y].filter((v) => { 
      console.log(v,v.name);
      if(v.name && q) {
      if (v.name.toLowerCase().indexOf(q.toLowerCase()) > -1) {
        //this.subitems1.push(v);
        return true;
      }
      //this.items2[x][y]=0;	
      return false;
      }
    }); 		
    }
    }
    //var len=this.items2.length;
    //this.items2.splice(0,len,this.subitems1);
    console.log(q, this.items2.length);
    console.log(this.items2);
    
    }
    
    private item_qty = 0;
    foodItemCount: number[]= new Array();
    count=0;
    
    //  changes from here
    private initialize(element)
    {
    //alert(this.foodItemCount[element]);
      if(this.foodItemCount[element]==null)
    this.foodItemCount[element]=0;
      
      //alert(element+" count is"+this.foodItemCount[element]);
    }	
    
    private increment (element,price) {
    if(this.foodItemCount[element]==0)
    {
    this.ordereditems.push(element);
    this.cost[element]=price;
    }
  
    this.foodItemCount[element]++;
    //alert(this.foodItemCount[element]);
    }
    
    private decrement (element) {
    if(this.foodItemCount[element]!=0)
    this.foodItemCount[element]--;
    if(this.foodItemCount[element]==0)
      {
        const index = this.ordereditems.indexOf(element, 0);
        if (index > -1)
         {
        this.ordereditems.splice(index, 1);
        }
      }
    
    }
  
    //changes till here	
       /*private addInCart(name,price,quantity){
        this.ordereditems.push(name);
        this.cost.push(price);
        this.qty.push(quantity);
        console.log(this.ordereditems);
         console.log(this.cost);
         console.log(this.qty);
        }*/
    
        private addFriend(uid:any,id:any,uemail:any,email:any)
        {
          console.log(id);
          this.firebaseProvider.sendFriendRequest(uid,id,uemail,email);
        }
  
        //changes
        private getPrice(value :any,data:any,x:any)
        {
          
          
          value.forEach(dataItem=> {
            let i=0;
            for(let y in Object.keys(dataItem))
            {
              this.aip[dataItem[y].$key]=dataItem[y].$value;
              
              i++;
            }
            console.log(this.aip+" ");
            this.items2[x].push({ name:data,availability:this.aip["Email"], price:this.aip["Name"]});
            this.aip.length=0;
            
          });
      //console.log(this.aip);
          
        }
    

}
