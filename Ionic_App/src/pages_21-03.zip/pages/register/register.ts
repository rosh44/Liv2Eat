import { Component } from '@angular/core';
import { NavController, NavParams, IonicPage } from 'ionic-angular';
import { User } from 'firebase';
import { AngularFireAuth} from 'angularfire2/auth';
import { LoginPage } from '../login/login';
import { UserStudent } from '../../model/userstudent';
import { UserFaculty } from '../../model/userfaculty';
import { FirebaseProvider } from './../../providers/firebase/firebase';

/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  regis:any;
  user = {} as User;
  userStud= {} as UserStudent;
  userFac= {} as UserFaculty;

  constructor(private aFuth: AngularFireAuth,
    public navCtrl: NavController, public navParams: NavParams, public firebaseProvider: FirebaseProvider) {
      this.regis = "stud";
  }

  async register(user: User)
  {
const result = await this.aFuth.auth.createUserWithEmailAndPassword(user.email, user.password);
console.log(result);
if(result)
{
  this.navCtrl.setRoot(LoginPage);
}
if(this.regis=='stud')
    {
      this.userStud.email=user.email;
      this.userStud.password=user.password;
      this.userStud.phnno=user.phonenumber;
      this.userStud.user="Student";
      this.firebaseProvider.addUserStud(this.userStud);
    }
    if(this.regis=='fac'){
      this.userFac.email=user.email;
      this.userFac.password=user.password;
      this.userFac.phnno=user.phonenumber;
      this.userFac.facId=user.facId;
      this.userFac.roomno=user.roomnumber;
      this.userFac.user="Faculty";
      this.firebaseProvider.addUserFac(this.userFac);
    }
  }

}
