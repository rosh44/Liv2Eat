import { Component } from '@angular/core';
import { NavController, NavParams, ToastController, ToastOptions } from 'ionic-angular';
import { User } from '../../model/user';
import { AngularFireAuth } from "angularfire2/auth";
import { RegisterPage } from '../register/register';
import { TabsPage } from "../tabs/tabs";
import { HomePage } from '../home/home';
/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
//@ts-ignore
export class LoginPage {
toastOptions: ToastOptions



 user = {} as User;
 error1: any;
  constructor(private aFauth: AngularFireAuth, private toastCtrl: ToastController,
    public navCtrl: NavController, public navParams: NavParams) {
      this.toastOptions = 
      {
        message: 'Bladlasdlasdl',
        duration: 5000
      }
  }

 async login(user: User)
 {
   
const result =  await this.aFauth.auth.signInWithEmailAndPassword(this.user.email, this.user.password);
console.log(result);
if(result)
{
  this.navCtrl.setRoot(TabsPage);
}
else
{
  
  this.toastCtrl.create(this.toastOptions).present(); 


this.navCtrl.setRoot(LoginPage);
}
 }


/* result.then(auth => {
  this.navCtrl.setRoot("HomePage");
})
.catch(
  
  error => {
    
  this.error1 = error;
 
  //this.navCtrl.setRoot("LoginPage");

  
  this.toastCtrl.create(this.toastOptions).present();

  console.log(error);
}); */

 register()
 {
   this.navCtrl.push(RegisterPage);
 }

}










 
  


