export const FIREBASE_CONFIG =  {
  apiKey: "AIzaSyDAAPiZM3ar79SWsmd2lXU0Y14po5t3Ho8",
  authDomain: "canteen-b59c6.firebaseapp.com",
  databaseURL: "https://canteen-b59c6.firebaseio.com",
  projectId: "canteen-b59c6",
  storageBucket: "canteen-b59c6.appspot.com",
  messagingSenderId: "210011172914"
};
 